#ifndef GAME
#define GAME


// define game states
const int PLAYING = 0;
const int WON = 1;

// define game boundaries

#endif